<?php 

$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "hpmodel_links` (
    `parent_id` int(10) NOT NULL,
    `product_id` int(10) unsigned NOT NULL,
    `sort` int(10) unsigned DEFAULT NULL,
    `image` varchar(255) NOT NULL DEFAULT '',
    `type_id` int(10) NOT NULL DEFAULT '0',
    PRIMARY KEY (`parent_id`, `product_id`),
    UNIQUE (`product_id`,`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";
$this->db->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "hpmodel_product_hidden` (
    `pid` int(11) NOT NULL,
    PRIMARY KEY (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";
$this->db->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "hpmodel_type` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `type` varchar(255) NOT NULL DEFAULT '',
    `setting` text NOT NULL DEFAULT '',
    `name` text,
    `description` text,
    `status` tinyint(1) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";
$this->db->query($sql);

$result = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "hpmodel_to_store'");
if ($result->num_rows == 0) {
    $sql = "CREATE TABLE `" . DB_PREFIX . "hpmodel_to_store` (
        `type_id` int(11) NOT NULL,
        `store_id` int(11) NOT NULL,
        PRIMARY KEY (`type_id`,`store_id`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";
    $this->db->query($sql);

    $stores = array(0);
    $query = $this->db->query("SELECT store_id FROM " . DB_PREFIX . "store");
    foreach ($query->rows as $store) {
        $stores[] = $store['store_id'];
    }
    
    $query = $this->db->query("SELECT `id` AS type_id  FROM `" . DB_PREFIX . "hpmodel_type`");
    foreach ($query->rows as $type) {
        foreach ($stores as $store_id) {
              $this->db->query("INSERT INTO `" . DB_PREFIX . "hpmodel_to_store` SET type_id = '" . (int)$type['type_id'] . "', store_id = '" . (int)$store_id . "'");
        }
    }
}
        
$result = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "hpmodel_links` LIKE 'image'");
if ($result->num_rows == 0) $this->db->query("ALTER TABLE `" . DB_PREFIX . "hpmodel_links` ADD COLUMN `image` varchar(255) NOT NULL DEFAULT ''"); 
$result = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "hpmodel_links` LIKE 'type_id'");
if ($result->num_rows == 0) $this->db->query("ALTER TABLE `" . DB_PREFIX . "hpmodel_links` ADD COLUMN `type_id` int(10) NOT NULL DEFAULT '0'");

$result = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "hpmodel_type` LIKE 'type'");
if ($result->num_rows == 0) $this->db->query("ALTER TABLE `" . DB_PREFIX . "hpmodel_type` ADD COLUMN `type` varchar(255) NOT NULL DEFAULT ''");                
$result = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "hpmodel_type` LIKE 'setting'");
if ($result->num_rows == 0) {
    $this->db->query("ALTER TABLE `" . DB_PREFIX . "hpmodel_type` ADD COLUMN `setting` text NOT NULL DEFAULT ''");
    
    $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hpmodel_type_details` ORDER BY id");
    $setting = array();
    foreach ($query->rows as $type_data) {
        $setting['category'] = explode(',', $type_data['category']);
        $setting['suppler'] = explode(',', $type_data['suppler']);
        $setting['manufacturer'] = explode(',', $type_data['manufacturer']);
        $setting['product_position'] = $type_data['product_position'];
        $setting['product_selector'] = $type_data['product_selector'];
        $setting['product_columns'] = json_decode($type_data['product_columns'], true);
        $setting['custom_css'] = $type_data['custom_css'];
        $setting['custom_js'] = $type_data['custom_js'];
        $setting['links'] = $type_data['links'];
        $setting['hidden_if_null'] = $type_data['hidden_if_null'];
        $setting['hidden_if_next'] = $type_data['hidden_if_next'];
        $setting['product_variant'] = $type_data['product_variant'];
        $setting['product_name_as_title'] = $type_data['product_name_as_title'];
        $setting['product_title'] = json_decode($type_data['product_title'], true);
        $setting['product_image_width'] = $type_data['product_image_width'];
        $setting['product_image_height'] = $type_data['product_image_height'];
        $setting['replace_image'] = $type_data['replace_image'];
        $setting['replace_desc'] = $type_data['replace_desc'];
        $setting['replace_att'] = $type_data['replace_att'];
        $setting['after_title'] = $type_data['after_title'];
        $this->db->query("UPDATE `" . DB_PREFIX . "hpmodel_type` SET `type` = '" . $this->db->escape($type_data['type']) . "', setting = '" . $this->db->escape(json_encode($setting)) . "' WHERE id = '" . (int)$type_data['id'] . "'");
    }
    $this->db->query("DROP TABLE `" . DB_PREFIX . "hpmodel_type_details`");
}
