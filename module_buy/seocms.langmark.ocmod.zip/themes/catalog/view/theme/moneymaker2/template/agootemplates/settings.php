<?php
$ascp_settings_settings = Array(
'css' => Array('css' => '
.seocmspro_content .owl-carousel {
display: flex;
}

@media screen and (max-width: 700px) {
.seocmspro_content  .owl-moneymaker2-products .product-layout.product-grid {
display: block !important;
width: 100% !important;
}
.seocmspro_content .owl-carousel {
display: block !important;
}
}
'));
