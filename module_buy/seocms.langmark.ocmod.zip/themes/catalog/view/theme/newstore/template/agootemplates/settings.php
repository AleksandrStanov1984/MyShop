<?php
$ascp_settings_settings = Array(
'box_begin' => '<div class="col-sm-12">
<div class="container-module">
<div class="title-module"><span>{TITLE}</span></div>',
'box_end' => '</div>
</div>
',
'css' => Array('css' => '
.seocmspro_content  .product-slider {
    margin: 0px;
}
.seocmspro_content  .blog-image {
	margin-right: 4px;
}
.seocmspro_content .container-module .title-module::after, .seocmspro_content .categorywall-container .title-module::after {
	border: none;
}
.seocmspro_content .container-module .title-module::before, .seocmspro_content .categorywall-container .title-module::before {
	border: none;
}
')
);
