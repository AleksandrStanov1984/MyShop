<?php
$ascp_settings_settings = Array(
'css' => Array ('css' => '
.seocmspro_content .box-type-17 .box {
    margin-top: 0px;
}
.seocmspro_content .box {
    padding-top: 0px;
    margin-top: 0px;
    position: static;
}
.seocmspro_content .box .box-content {
    padding:  0px;
}
.seocmspro_content .tab-content {
	margin-top: 0px;
	padding-top: 0px;
}

.seocmspro_content .box-product .carousel {
	overflow: hidden;
	margin: 0px !important;
	padding: 0px  !important;
}

.center-column  .seocmspro_content .tab-content {
	padding: 0px !important;
}

.fixed-body .center-column  .seocmspro_content .tab-content {
	margin: 0px 0px;
	padding-left: 0px;
	padding-right: 0px;
}

.seocmspro_content .tab-content, .seocmspro_content .tab-content::before, .seocmspro_content .tab-content::after {
	background: none !important;
}
'
)
);
