<?php
$_['entry_langmark'] = 'SEO мультиязык';