<?php
$_['text_widget_html']          = 'Insert Html';
$_['text_blog']     = 'categories';
