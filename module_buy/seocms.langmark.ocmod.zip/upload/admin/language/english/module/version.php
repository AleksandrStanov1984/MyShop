<?php
$_['blog_version'] = '56.3';