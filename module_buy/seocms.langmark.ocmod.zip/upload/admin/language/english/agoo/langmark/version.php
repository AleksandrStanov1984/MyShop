<?php
$_['text_widget_langmark_version'] = $_['langmark_version'] = '25.0';