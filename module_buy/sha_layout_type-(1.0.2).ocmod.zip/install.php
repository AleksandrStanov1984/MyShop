<?php
	$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "layout_route_type` (
	`layout_sha_type_id` int(11) NOT NULL AUTO_INCREMENT,
	`layout_id` int(11) NOT NULL,
	`store_id` int(11) NOT NULL,
	`route` varchar(64) NOT NULL,
	`layout_type` int(1) DEFAULT NULL,
	PRIMARY KEY (`layout_sha_type_id`)
	) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");
?>