create definer = admin_testuser33@localhost trigger reverse_sort_order_before_update_stock_status
    before update
    on oc_product
    for each row
    IF NEW.stock_status_id = '7' AND NEW.sort_order > 100 OR NEW.stock_status_id = '8' AND NEW.sort_order > 100 THEN
   SET NEW.sort_order = '100';
END IF;

