create definer = admin_testuser33@localhost trigger before_insert_url_alias
    before insert
    on oc_url_alias
    for each row
    SET NEW.keyword = CAST(REGEXP_REPLACE(NEW.keyword, '[^A-Za-z0-9/_-]', '-') AS CHAR);

