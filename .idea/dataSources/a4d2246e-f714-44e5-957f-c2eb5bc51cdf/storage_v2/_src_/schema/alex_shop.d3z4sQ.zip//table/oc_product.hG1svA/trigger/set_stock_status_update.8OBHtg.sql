create definer = admin_testuser33@localhost trigger set_stock_status_update
    before update
    on oc_product
    for each row
    IF NEW.sort_order = '0' THEN
   SET NEW.sort_order='100';
END IF;

