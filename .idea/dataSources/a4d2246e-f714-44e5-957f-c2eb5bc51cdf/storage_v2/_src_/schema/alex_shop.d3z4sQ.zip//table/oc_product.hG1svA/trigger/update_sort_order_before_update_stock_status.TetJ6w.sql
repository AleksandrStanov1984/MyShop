create definer = admin_testuser33@localhost trigger update_sort_order_before_update_stock_status
    before update
    on oc_product
    for each row
    IF NEW.stock_status_id = '5' THEN
   SET NEW.sort_order='101';
END IF;

